package com.karambitmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.ClickableWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.DoubleConsumer;
import java.util.function.DoubleSupplier;
import java.util.function.Function;
import java.util.function.IntConsumer;
import java.util.function.IntSupplier;
import java.util.function.Supplier;

/** Menu moda (klawisz P). Ciemny panel z gradientowym akcentem i własnymi widżetami. */
public class ConfigScreen extends Screen {
    private static final String[] TABS = {"Ogólne", "Karambit", "Cząsteczki", "Deszcz", "Spotify",
            "Teraz gra", "Info", "Ekwipunek", "Efekty", "Narzędzia"};
    private static String version;
    private static final int PW = 440;
    private static final int ROW = 22;
    private static final int TOP = 80;
    private static int tab = 0;

    private final Screen parent;
    private int slot;
    private boolean dimmed;                                  // widżety po wyłączonym module są nieaktywne
    private final List<Object[]> labels = new ArrayList<>();    // {x, y, tekst}
    private final List<Object[]> swatches = new ArrayList<>();  // {x, y, IntSupplier}

    public ConfigScreen(Screen parent) {
        super(Text.literal("Karambit Mod"));
        this.parent = parent;
    }

    private int px() { return width / 2 - PW / 2; }

    // ============================================================ widżety (płaski, minimalistyczny styl)

    static final int BG = 0xFF1B1B24, BG_HOVER = 0xFF262633, BG_OFF = 0xFF15151B;
    static final int BORDER = 0xFF2C2C3B, BORDER_HOVER = 0xFF5B4A99, BORDER_OFF = 0xFF20202A;
    static final int ACCENT = 0xFF8A5CFF, ACCENT_HOVER = 0xFF9D77FF;
    static final int TXT = 0xFFE6E6EE, TXT_OFF = 0xFF5A5A68;
    static final int PANEL = 0xFF101014, CARD = 0xFF13131A;

    /** Przycisk z zaokrąglonymi rogami, płynnym podświetleniem i opcjonalnym przełącznikiem po prawej. */
    static class Btn extends ButtonWidget {
        protected final BooleanSupplier selected, sw;
        protected final boolean centered;
        boolean accent, chevron;
        float hv, kn = -1f;

        Btn(int x, int y, int w, int h, net.minecraft.text.Text msg, PressAction act, BooleanSupplier selected, BooleanSupplier sw, boolean centered) {
            super(x, y, w, h, msg, act, DEFAULT_NARRATION_SUPPLIER);
            this.selected = selected; this.sw = sw; this.centered = centered;
        }

        protected void tick(boolean hov) { hv += ((hov ? 1f : 0f) - hv) * 0.3f; }

        // PressableWidget#renderWidget jest final; drawIcon wywoływane jest po tle vanilla,
        // więc rysujemy własny, w pełni kryjący przycisk na wierzchu.
        @Override
        public void drawIcon(DrawContext c, int mx, int my, float d) {
            TextRenderer tr = MinecraftClient.getInstance().textRenderer;
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            boolean act = active;
            tick(act && isHovered());
            int ty = y + (h - 8) / 2;

            if (accent && act) {
                Gui.roundRect(c, x, y, x + w, y + h, 3, Gui.mix(ACCENT, 0xFFB9A0FF, hv));
                Gui.hGradient(c, x + 1, y + 1, w - 2, h - 2, Gui.mix(Gui.ACCENT_A, 0xFFFFFF, hv * 0.25f), Gui.mix(Gui.ACCENT_B, 0xFFFFFF, hv * 0.25f));
                c.drawCenteredTextWithShadow(tr, getMessage(), x + w / 2, ty, 0xFFFFFFFF);
                return;
            }

            int bg = !act ? BG_OFF : Gui.mix(BG, BG_HOVER, hv);
            int bd = !act ? BORDER_OFF : Gui.mix(BORDER, BORDER_HOVER, hv);
            Gui.framed(c, x, y, x + w, y + h, 3, bd, bg);
            int tc = act ? TXT : TXT_OFF;
            if (centered) c.drawCenteredTextWithShadow(tr, getMessage(), x + w / 2, ty, tc);
            else c.drawTextWithShadow(tr, getMessage(), x + 8, ty, tc);

            if (sw != null) {
                boolean on = sw.getAsBoolean();
                if (kn < 0) kn = on ? 1f : 0f;
                kn += ((on ? 1f : 0f) - kn) * 0.35f;
                int sx = x + w - 34, sy = y + (h - 12) / 2;
                int track = !act ? 0xFF22222C : Gui.mix(0xFF3A3A4A, ACCENT, kn);
                Gui.roundRect(c, sx, sy, sx + 24, sy + 12, 6, track);
                int kx = sx + 2 + Math.round(kn * 12);
                Gui.roundRect(c, kx, sy + 2, kx + 8, sy + 10, 4, act ? 0xFFFFFFFF : TXT_OFF);
            } else if (chevron) {
                c.drawTextWithShadow(tr, net.minecraft.text.Text.literal("›"), x + w - 12, ty, act ? Gui.mix(0xFF70707E, ACCENT, hv) : TXT_OFF);
            }
        }
    }

    /** Zakładka: zaokrąglona kapsuła, zaznaczona ma gradientowe podkreślenie. */
    static class TabBtn extends Btn {
        TabBtn(int x, int y, int w, int h, net.minecraft.text.Text msg, PressAction act, BooleanSupplier selected) {
            super(x, y, w, h, msg, act, selected, null, true);
        }

        @Override
        public void drawIcon(DrawContext c, int mx, int my, float d) {
            TextRenderer tr = MinecraftClient.getInstance().textRenderer;
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            boolean sel = selected.getAsBoolean();
            tick(isHovered());
            Gui.roundRect(c, x, y, x + w, y + h, 4, sel ? 0xFF211C3A : Gui.mix(PANEL, BG, hv));
            int col = sel ? 0xFFFFFFFF : Gui.mix(0xFF70707E, 0xFFD0D0DC, hv);
            c.drawCenteredTextWithShadow(tr, getMessage(), x + w / 2, y + 4, col);
            if (sel) Gui.pillGradient(c, x + 10, y + h - 4, w - 20, 2, Gui.ACCENT_A, Gui.ACCENT_B);
        }
    }

    /** Suwak: zaokrąglony tor z gradientowym wypełnieniem i jasnym uchwytem. */
    abstract static class Sl extends SliderWidget {
        float hv;

        Sl(int x, int y, int w, int h, double v) { super(x, y, w, h, net.minecraft.text.Text.empty(), v); }

        @Override
        public void renderWidget(DrawContext c, int mx, int my, float d) {
            TextRenderer tr = MinecraftClient.getInstance().textRenderer;
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            boolean act = active;
            hv += (((act && isHovered()) ? 1f : 0f) - hv) * 0.3f;
            Gui.framed(c, x, y, x + w, y + h, 3, act ? Gui.mix(BORDER, BORDER_HOVER, hv) : BORDER_OFF, act ? BG : BG_OFF);
            int inner = w - 4;
            int fill = (int) (inner * value);
            for (int i = 0; i < fill; i++) {
                int col = act ? Gui.mix(Cfg.lerp(Gui.ACCENT_A, Gui.ACCENT_B, (float) i / Math.max(1, inner - 1)), 0x101018, 0.55f) : 0xFF1E1E28;
                c.fill(x + 2 + i, y + 2, x + 3 + i, y + h - 2, col);
            }
            int kx = Math.max(x + 1, Math.min(x + w - 4, x + 2 + fill - 1));
            c.fill(kx, y + 1, kx + 3, y + h - 1, act ? Gui.mix(0xFFCFC2FF, 0xFFFFFFFF, hv) : 0xFF3A3A48);
            c.drawCenteredTextWithShadow(tr, getMessage(), x + w / 2, y + (h - 8) / 2, act ? TXT : TXT_OFF);
        }
    }

    /** Pole tekstowe z cienką ramką, która robi się akcentowa po kliknięciu. */
    static class Field extends TextFieldWidget {
        Field(TextRenderer tr, int x, int y, int w, int h, Text msg) { super(tr, x, y, w, h, msg); }

        @Override
        public void renderWidget(DrawContext c, int mx, int my, float d) {
            super.renderWidget(c, mx, my, d);
            int x = getX(), y = getY(), w = getWidth(), h = getHeight();
            int col = isFocused() ? ACCENT : (active ? BORDER : BORDER_OFF);
            c.fill(x, y, x + w, y + 1, col);
            c.fill(x, y + h - 1, x + w, y + h, col);
            c.fill(x, y + 1, x + 1, y + h - 1, col);
            c.fill(x + w - 1, y + 1, x + w, y + h - 1, col);
        }
    }

    // ============================================================ układ

    private int nextX() { return px() + 14 + (slot % 2) * 212; }
    private int nextY() { return TOP + (slot / 2) * ROW; }
    private void skipToNextRow() { if (slot % 2 == 1) slot++; }

    @Override
    protected void init() {
        labels.clear();
        swatches.clear();
        slot = 0;
        dimmed = false;
        final int perRow = 5;
        final int tw = (PW - 12 - 4 * (perRow - 1)) / perRow;
        for (int i = 0; i < TABS.length; i++) {
            final int idx = i;
            addDrawableChild(new TabBtn(px() + 6 + (i % perRow) * (tw + 4), 26 + (i / perRow) * 22, tw, 20, Text.literal(TABS[i]),
                    b -> { tab = idx; clearAndInit(); }, () -> tab == idx));
        }
        switch (tab) {
            case 0 -> initGeneral();
            case 1 -> initKarambit();
            case 2 -> initParticles();
            case 3 -> initRain();
            case 4 -> initSpotify();
            case 5 -> initHud();
            case 6 -> initInfo();
            case 7 -> initEquip();
            case 8 -> initEffects();
            default -> initTools();
        }
        dimmed = false;
        Btn done = new Btn(width / 2 - 60, height - 30, 120, 20, Text.literal("Gotowe"),
                b -> close(), () -> false, null, true);
        done.accent = true;
        addDrawableChild(done);
    }

    @Override public void removed() { Cfg.save(); }

    @Override
    public void close() {
        Cfg.save();
        if (client != null) client.setScreen(parent);
    }

    // ============================================================ zakładki

    private void initGeneral() {
        Cfg c = Cfg.I;
        master("Mod włączony (wszystko)", () -> c.modEnabled, v -> c.modEnabled = v);
        addDrawableChild(new Btn(nextX(), nextY(), 200, 18, Text.literal("Przywróć ustawienia domyślne"),
                b -> { Cfg.resetKeepingSpotify(); clearAndInit(); }, () -> false, null, false));
        slot++;
        toggle("Karambit zamiast mieczy", () -> c.karambitEnabled, v -> c.karambitEnabled = v);
        toggle("Cząsteczki", () -> c.particlesEnabled, v -> c.particlesEnabled = v);
        toggle("Deszcz (odbijające się krople)", () -> c.rainEnabled, v -> c.rainEnabled = v);
        toggle("Spotify (połączenie i sterowanie)", () -> c.spotifyEnabled, v -> c.spotifyEnabled = v);
        toggle("Okienko \"Teraz gra\"", () -> c.hudEnabled, v -> c.hudEnabled = v);
        toggle("Panel informacji (FPS, XYZ...)", () -> c.infoEnabled, v -> c.infoEnabled = v);
        toggle("Ekwipunek HUD (pancerz)", () -> c.equipEnabled, v -> c.equipEnabled = v);
        toggle("Efekty świata", () -> c.effectsEnabled, v -> c.effectsEnabled = v);
        toggle("Pasek życia celu", () -> c.targetEnabled, v -> c.targetEnabled = v);
        toggle("Kompas", () -> c.compassEnabled, v -> c.compassEnabled = v);
    }

    private void initKarambit() {
        Cfg c = Cfg.I;
        master("Karambit zamiast mieczy", () -> c.karambitEnabled, v -> c.karambitEnabled = v);
        cycle("Kształt", new Integer[]{0, 1, 2}, () -> c.karambitShape, v -> c.karambitShape = v, v -> Cfg.SHAPE_NAMES[v]);
        Integer[] pal = {0, 1, 2, 3, 4, 5, 6, 7, 8, 9};
        cycle("Kolor A (rękojeść)", pal, () -> c.karambitColorA, v -> c.karambitColorA = v, v -> Cfg.PALETTE_NAMES[v]);
        cycle("Kolor B (czubek)", pal, () -> c.karambitColorB, v -> c.karambitColorB = v, v -> Cfg.PALETTE_NAMES[v]);
    }

    private void initParticles() {
        Cfg c = Cfg.I;
        master("Cząsteczki", () -> c.particlesEnabled, v -> c.particlesEnabled = v);
        toggle("Tylko z mieczem w ręce", () -> c.onlyWithSword, v -> c.onlyWithSword = v);
        cycle("Miejsce", Cfg.Anchor.values(), () -> c.anchor, v -> c.anchor = v, v -> switch (v) {
            case HELD_ITEM -> "Miecz w ręce";
            case TARGET_BLOCK -> "Wskazywany blok";
            case PLAYER -> "Wokół gracza";
        });
        cycle("Kształt", Cfg.PShape.values(), () -> c.particleShape, v -> c.particleShape = v, v -> switch (v) {
            case ORBIT -> "Orbita";
            case HELIX -> "Spirala";
            case RING -> "Pierścień";
            case STAR -> "Gwiazda";
            case HEART -> "Serce";
            case CUBE -> "Sześcian";
            case SPHERE -> "Sfera";
            case CLOUD -> "Chmura";
            case LINE -> "Smuga";
        });
        cycle("Typ", Cfg.PType.values(), () -> c.particleType, v -> c.particleType = v, v -> switch (v) {
            case DUST -> "Kolorowy pył";
            case END_ROD -> "Iskry Endu";
            case FLAME -> "Ogień";
            case SOUL_FIRE -> "Ogień dusz";
            case ELECTRIC_SPARK -> "Elektryczne";
            case HAPPY_VILLAGER -> "Zielone gwiazdki";
        });
        toggle("Gradient kolorów", () -> c.particleGradient, v -> c.particleGradient = v);
        hex("Kolor A (hex)", () -> c.particleColorA, v -> c.particleColorA = v);
        hex("Kolor B (hex)", () -> c.particleColorB, v -> c.particleColorB = v);
        slider("Ilość / tick", 1, 40, () -> c.particleCount, v -> c.particleCount = (int) Math.round(v), "%.0f");
        slider("Rozmiar", 0.3, 3, () -> c.particleSize, v -> c.particleSize = (float) v, "%.1f");
        slider("Promień", 0.2, 2.5, () -> c.particleRadius, v -> c.particleRadius = (float) v, "%.2f");
        slider("Prędkość", 0.1, 4, () -> c.particleSpeed, v -> c.particleSpeed = (float) v, "%.1f");
    }

    private void initRain() {
        Cfg c = Cfg.I;
        master("Odbijające się krople", () -> c.rainEnabled, v -> c.rainEnabled = v);
        toggle("Plusk po upadku", () -> c.rainSplash, v -> c.rainSplash = v);
        slider("Gęstość", 1, 15, () -> c.rainDensity, v -> c.rainDensity = (int) Math.round(v), "%.0f");
        slider("Sprężystość", 0.2, 0.9, () -> c.rainBounce, v -> c.rainBounce = (float) v, "%.2f");
        slider("Rozmiar kropli", 0.3, 2, () -> c.rainSize, v -> c.rainSize = (float) v, "%.1f");
        slider("Zasięg", 4, 24, () -> c.rainRadius, v -> c.rainRadius = (float) v, "%.0f bl.");
        toggle("Gradient kolorów", () -> c.rainGradient, v -> c.rainGradient = v);
        skipToNextRow();
        hex("Kolor A (hex)", () -> c.rainColorA, v -> c.rainColorA = v);
        hex("Kolor B (hex)", () -> c.rainColorB, v -> c.rainColorB = v);
    }

    private void initSpotify() {
        Cfg c = Cfg.I;
        int cx = width / 2;
        int o = TOP - 60;
        Btn m = new Btn(cx - 100, 58 + o, 200, 20, Text.literal("Spotify włączony"),
                btn -> { c.spotifyEnabled = !c.spotifyEnabled; clearAndInit(); }, () -> false, () -> c.spotifyEnabled, false);
        addDrawableChild(m);
        dimmed = !c.spotifyEnabled;

        labels.add(new Object[]{cx - 100, 83 + o, "Spotify Client ID"});
        TextFieldWidget id = new Field(textRenderer, cx - 100, 93 + o, 200, 20, Text.literal("Client ID"));
        id.setMaxLength(64);
        id.setPlaceholder(Text.literal("Wklej Client ID z developer.spotify.com"));
        id.setText(c.spotifyClientId);
        id.setChangedListener(s -> c.spotifyClientId = s.trim());
        id.setEditable(!dimmed);
        addDrawableChild(id);

        Btn con = new Btn(cx - 100, 117 + o, 98, 20, Text.literal("Połącz"), b -> { Cfg.save(); Spotify.connect(); }, () -> false, null, true);
        con.accent = true;
        put(con);
        put(new Btn(cx + 2, 117 + o, 98, 20, Text.literal("Odłącz"), b -> Spotify.disconnect(), () -> false, null, true));

        labels.add(new Object[]{cx - 100, 159 + o, "Sterowanie (wymaga Premium)"});
        put(new Btn(cx - 100, 169 + o, 64, 20, Text.literal("⏮"), b -> Spotify.previous(), () -> false, null, true));
        put(new Btn(cx - 32, 169 + o, 64, 20, Text.literal("⏯"), b -> Spotify.playPause(), () -> false, null, true));
        put(new Btn(cx + 36, 169 + o, 64, 20, Text.literal("⏭"), b -> Spotify.next(), () -> false, null, true));
        labels.add(new Object[]{cx - 100, 195 + o, "Redirect URI: §ahttp://127.0.0.1:8888/callback"});
    }

    private void initHud() {
        Cfg c = Cfg.I;
        master("Pokaż \"Teraz gra\"", () -> c.hudEnabled, v -> c.hudEnabled = v);
        toggle("Pasek postępu", () -> c.hudProgress, v -> c.hudProgress = v);
        toggle("Gradient tekstu", () -> c.hudGradient, v -> c.hudGradient = v);
        skipToNextRow();
        hex("Kolor A (hex)", () -> c.hudColorA, v -> c.hudColorA = v);
        hex("Kolor B (hex)", () -> c.hudColorB, v -> c.hudColorB = v);
        slider("Pozycja X", 0, 100, () -> c.hudX, v -> c.hudX = (float) v, "%.0f%%");
        slider("Pozycja Y", 0, 100, () -> c.hudY, v -> c.hudY = (float) v, "%.0f%%");
        slider("Skala", 0.5, 2.5, () -> c.hudScale, v -> c.hudScale = (float) v, "%.1f");
    }

    private void initInfo() {
        Cfg c = Cfg.I;
        master("Panel informacji", () -> c.infoEnabled, v -> c.infoEnabled = v);
        toggle("Tło panelu", () -> c.infoBg, v -> c.infoBg = v);
        toggle("FPS", () -> c.infoFps, v -> c.infoFps = v);
        toggle("Ping", () -> c.infoPing, v -> c.infoPing = v);
        toggle("Współrzędne i kierunek", () -> c.infoCoords, v -> c.infoCoords = v);
        toggle("Prędkość (bloki/s)", () -> c.infoSpeed, v -> c.infoSpeed = v);
        toggle("Poziom światła (mobki)", () -> c.infoLight, v -> c.infoLight = v);
        toggle("Zegar (czas rzeczywisty)", () -> c.infoClock, v -> c.infoClock = v);
        hex("Kolor A (hex)", () -> c.infoColorA, v -> c.infoColorA = v);
        hex("Kolor B (hex)", () -> c.infoColorB, v -> c.infoColorB = v);
        slider("Pozycja X", 0, 100, () -> c.infoX, v -> c.infoX = (float) v, "%.0f%%");
        slider("Pozycja Y", 0, 100, () -> c.infoY, v -> c.infoY = (float) v, "%.0f%%");
        slider("Skala", 0.5, 2.5, () -> c.infoScale, v -> c.infoScale = (float) v, "%.1f");
    }

    private void initEquip() {
        Cfg c = Cfg.I;
        master("Ekwipunek HUD", () -> c.equipEnabled, v -> c.equipEnabled = v);
        toggle("Pancerz (wytrzymałość)", () -> c.equipArmor, v -> c.equipArmor = v);
        toggle("Przedmiot w ręce", () -> c.equipHeld, v -> c.equipHeld = v);
        cycle("Wartości", Cfg.ValueMode.values(), () -> c.equipMode, v -> c.equipMode = v, v -> switch (v) {
            case PERCENT -> "Procenty";
            case NUMBERS -> "Liczby";
        });
        toggle("Licznik: Totemy", () -> c.equipTotem, v -> c.equipTotem = v);
        toggle("Licznik: Perły Endu", () -> c.equipPearl, v -> c.equipPearl = v);
        toggle("Licznik: Złote jabłka", () -> c.equipApple, v -> c.equipApple = v);
        toggle("Licznik: Strzały", () -> c.equipArrow, v -> c.equipArrow = v);
        toggle("Licznik: Kryształy Endu", () -> c.equipCrystal, v -> c.equipCrystal = v);
        cycle("Układ", Cfg.Layout.values(), () -> c.equipLayout, v -> c.equipLayout = v, v -> switch (v) {
            case VERTICAL -> "Pionowo";
            case HORIZONTAL -> "Poziomo";
        });
        slider("Pozycja X", 0, 100, () -> c.equipX, v -> c.equipX = (float) v, "%.0f%%");
        slider("Pozycja Y", 0, 100, () -> c.equipY, v -> c.equipY = (float) v, "%.0f%%");
        slider("Skala", 0.5, 2.5, () -> c.equipScale, v -> c.equipScale = (float) v, "%.1f");
    }

    private void initEffects() {
        Cfg c = Cfg.I;
        master("Efekty świata", () -> c.effectsEnabled, v -> c.effectsEnabled = v);
        cycle("Typ", Cfg.PType.values(), () -> c.fxType, v -> c.fxType = v, v -> switch (v) {
            case DUST -> "Kolorowy pył";
            case END_ROD -> "Iskry Endu";
            case FLAME -> "Ogień";
            case SOUL_FIRE -> "Ogień dusz";
            case ELECTRIC_SPARK -> "Elektryczne";
            case HAPPY_VILLAGER -> "Zielone gwiazdki";
        });
        toggle("Ślad kroków", () -> c.fxTrail, v -> c.fxTrail = v);
        toggle("Ślad tylko w sprincie", () -> c.fxTrailSprint, v -> c.fxTrailSprint = v);
        toggle("Iskry przy trafieniu", () -> c.fxHit, v -> c.fxHit = v);
        slider("Ilość iskier", 3, 60, () -> c.fxHitCount, v -> c.fxHitCount = (int) Math.round(v), "%.0f");
        toggle("Świetliki", () -> c.fxFireflies, v -> c.fxFireflies = v);
        slider("Ilość świetlików", 3, 60, () -> c.fxFlyCount, v -> c.fxFlyCount = (int) Math.round(v), "%.0f");
        toggle("Świetliki tylko po ciemku", () -> c.fxDarkOnly, v -> c.fxDarkOnly = v);
        slider("Rozmiar", 0.4, 2.5, () -> c.fxSize, v -> c.fxSize = (float) v, "%.1f");
        hex("Kolor A (hex)", () -> c.fxColorA, v -> c.fxColorA = v);
        hex("Kolor B (hex)", () -> c.fxColorB, v -> c.fxColorB = v);
    }

    private void initTools() {
        Cfg c = Cfg.I;
        toggle("Zoom (trzymaj klawisz)", () -> c.zoomEnabled, v -> c.zoomEnabled = v);
        slider("FOV przy zoomie", 30, 60, () -> c.zoomFov, v -> c.zoomFov = (int) Math.round(v), "%.0f");
        toggle("Płynny zoom", () -> c.zoomSmooth, v -> c.zoomSmooth = v);
        toggle("Pełna jasność", () -> c.fullbright, v -> c.fullbright = v);
        toggle("Pasek życia celu", () -> c.targetEnabled, v -> c.targetEnabled = v);
        toggle("Dystans do celu", () -> c.targetDistance, v -> c.targetDistance = v);
        toggle("Kompas", () -> c.compassEnabled, v -> c.compassEnabled = v);
        slider("Szerokość kompasu", 120, 280, () -> c.compassWidth, v -> c.compassWidth = (int) Math.round(v), "%.0f");
        slider("Cel: odstęp od celownika", 10, 80, () -> c.targetOffset, v -> c.targetOffset = (int) Math.round(v), "%.0f px");
    }

    // ============================================================ fabryki widżetów

    private <T extends ClickableWidget> T put(T w) {
        w.active = !dimmed;
        return addDrawableChild(w);
    }

    /** Główny włącznik zakładki: po wyłączeniu reszta opcji jest przyciemniona i nieaktywna. */
    private void master(String label, BooleanSupplier get, Consumer<Boolean> set) {
        Btn b = new Btn(nextX(), nextY(), 200, 18, Text.literal(label),
                btn -> { set.accept(!get.getAsBoolean()); clearAndInit(); }, () -> false, get, false);
        slot++;
        addDrawableChild(b);
        dimmed = !get.getAsBoolean();
    }

    private void toggle(String label, BooleanSupplier get, Consumer<Boolean> set) {
        Btn b = new Btn(nextX(), nextY(), 200, 18, Text.literal(label),
                btn -> set.accept(!get.getAsBoolean()), () -> false, get, false);
        slot++;
        put(b);
    }

    private <T> void cycle(String label, T[] values, Supplier<T> get, Consumer<T> set, Function<T, String> name) {
        Btn b = new Btn(nextX(), nextY(), 200, 18, Text.literal(label + ": " + name.apply(get.get())), btn -> {
            int idx = 0;
            for (int i = 0; i < values.length; i++) if (values[i].equals(get.get())) idx = i;
            T nv = values[(idx + 1) % values.length];
            set.accept(nv);
            btn.setMessage(Text.literal(label + ": " + name.apply(nv)));
        }, () -> false, null, false);
        b.chevron = true;
        slot++;
        put(b);
    }

    private void slider(String label, double min, double max, DoubleSupplier get, DoubleConsumer set, String fmt) {
        final double span = max - min;
        Sl w = new Sl(nextX(), nextY(), 200, 18, (get.getAsDouble() - min) / span) {
            { updateMessage(); }
            @Override protected void updateMessage() {
                setMessage(Text.literal(label + ": " + String.format(fmt, min + value * span)));
            }
            @Override protected void applyValue() { set.accept(min + value * span); }
        };
        slot++;
        put(w);
    }

    private void hex(String label, IntSupplier get, IntConsumer set) {
        int x = nextX(), y = nextY();
        labels.add(new Object[]{x + 4, y + 5, label});
        swatches.add(new Object[]{x + 98, y + 2, get});
        TextFieldWidget f = new Field(textRenderer, x + 120, y, 80, 18, Text.literal(label));
        f.setMaxLength(6);
        f.setText(String.format("%06X", get.getAsInt() & 0xFFFFFF));
        f.setChangedListener(s -> {
            if (s.length() == 6) {
                try { set.accept(Integer.parseInt(s, 16)); } catch (NumberFormatException ignored) {}
            }
        });
        slot++;
        f.setEditable(!dimmed);
        addDrawableChild(f);
    }

    // ============================================================ rysowanie

    @Override
    public void renderBackground(DrawContext ctx, int mx, int my, float delta) {
        super.renderBackground(ctx, mx, my, delta);
        int x = px(), y1 = 8, y2 = height - 6;
        Gui.shadow(ctx, x, y1, x + PW, y2, 5);
        Gui.framed(ctx, x, y1, x + PW, y2, 5, 0xFF2A2A3A, PANEL);
        Gui.pillGradient(ctx, x + 8, y1 + 1, PW - 16, 2, Gui.ACCENT_A, Gui.ACCENT_B);
        ctx.drawTextWithShadow(textRenderer, Gui.gradientText("Karambit Mod", Gui.ACCENT_A, Gui.ACCENT_B), x + 14, 14, 0xFFFFFFFF);
        if (version == null) version = net.fabricmc.loader.api.FabricLoader.getInstance().getModContainer(KarambitMod.ID)
                .map(m -> "v" + m.getMetadata().getVersion().getFriendlyString()).orElse("");
        String ver = version;
        ctx.drawTextWithShadow(textRenderer, Text.literal(ver), x + PW - 14 - textRenderer.getWidth(ver), 14, 0xFF6A6A7A);
        ctx.fill(x + 10, 71, x + PW - 10, 72, 0xFF22222E);
        Gui.roundRect(ctx, x + 8, 76, x + PW - 8, height - 36, 4, CARD);
    }

    /** Pigułka z tekstem (np. status, podpowiedź). */
    private void pill(DrawContext ctx, int x1, int y1, int x2, int y2) {
        Gui.framed(ctx, x1, y1, x2, y2, 3, BORDER, BG);
    }

    @Override
    public void render(DrawContext ctx, int mx, int my, float delta) {
        super.render(ctx, mx, my, delta);
        for (Object[] l : labels)
            ctx.drawTextWithShadow(textRenderer, Text.literal((String) l[2]), (int) l[0], (int) l[1], 0xFFBBBBCC);
        for (Object[] s : swatches) {
            int sx = (int) s[0], sy = (int) s[1];
            int col = ((IntSupplier) s[2]).getAsInt();
            Gui.framed(ctx, sx - 1, sy - 1, sx + 15, sy + 15, 3, 0xFF3A3A4A, 0xFF000000 | col);
        }
        Cfg c = Cfg.I;
        int cx = width / 2;
        switch (tab) {
            case 0 -> {
                String hint = "Klawisz menu: P  (zmiana: Opcje → Sterowanie → Karambit Mod)";
                int hw = textRenderer.getWidth(hint);
                int hy = TOP + 6 * ROW + 4;
                pill(ctx, cx - hw / 2 - 8, hy, cx + hw / 2 + 8, hy + 16);
                ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(hint), cx, hy + 4, 0xFF9A9AAE);
            }
            case 1 -> {
                int fy = TOP + 2 * ROW + 6;
                Gui.framed(ctx, cx - 50, fy, cx + 50, fy + 84, 4, BORDER, 0xFF16161C);
                ctx.getMatrices().pushMatrix();
                ctx.getMatrices().translate(cx - 32, fy + 10);
                ctx.getMatrices().scale(4f, 4f);
                ctx.drawItem(new ItemStack(Items.DIAMOND_SWORD), 0, 0);   // mixin podmienia go na karambita
                ctx.getMatrices().popMatrix();
                Gui.pillGradient(ctx, cx - 100, fy + 91, 200, 4, palette(c.karambitColorA), palette(c.karambitColorB));
            }
            case 3 -> {
                int fy = TOP + 5 * ROW + 6;
                Gui.pillGradient(ctx, cx - 100, fy, 200, 4, c.rainColorA, c.rainGradient ? c.rainColorB : c.rainColorA);
            }
            case 4 -> {
                String st = Spotify.status;
                boolean ok = c.spotifyEnabled && Spotify.isLinked() && !st.startsWith("Błąd") && !st.contains("Premium");
                pill(ctx, cx - 100, TOP + 81, cx + 100, TOP + 97);
                Gui.roundRect(ctx, cx - 94, TOP + 86, cx - 88, TOP + 92, 3, ok ? 0xFF1DB954 : 0xFFE5484D);
                ctx.drawTextWithShadow(textRenderer, Text.literal(st), cx - 82, TOP + 85, 0xFFFFFFFF);
            }
            case 5 -> {
                Gui.pillGradient(ctx, cx - 100, TOP + 4 * ROW + 8, 200, 4, c.hudColorA, c.hudGradient ? c.hudColorB : c.hudColorA);
                Spotify.Track t = Spotify.track;
                if (t == null) t = new Spotify.Track("Przykładowy utwór", "Wykonawca", 63000, 215000, true, System.currentTimeMillis());
                if (c.hudEnabled && c.modEnabled) HudRenderer.draw(ctx, textRenderer, t, width, height);   // podgląd na żywo
            }
            case 6 -> { if (c.modEnabled && c.infoEnabled) HudWidgets.drawInfo(ctx, textRenderer, width, height); }
            case 7 -> { if (c.modEnabled && c.equipEnabled) HudWidgets.drawEquip(ctx, textRenderer, width, height, true); }
            case 8 -> Gui.pillGradient(ctx, cx - 100, TOP + 6 * ROW + 2, 200, 4, c.fxColorA, c.fxColorB);
            case 9 -> {
                int py = TOP + 5 * ROW + 10;
                float yaw = client != null && client.player != null ? client.player.getYaw() : 0f;
                HudWidgets.targetCard(ctx, textRenderer, px() + 14 + 56, py, "Zombie", 14f, 20f, c.targetDistance ? 5.2f : -1f);
                HudWidgets.compassAt(ctx, textRenderer, px() + 140 + 140, py + 6, Math.min(c.compassWidth, 250), yaw);
                String hint = "Zoom: klawisz Z (Opcje → Sterowanie)";
                ctx.drawCenteredTextWithShadow(textRenderer, Text.literal(hint), cx, TOP + 5 * ROW - 2, 0xFF9A9AAE);
            }
            default -> {}
        }
    }

    private static int palette(int idx) {
        int[] p = {0xDC2832, 0xFF8C1E, 0xFADC32, 0x3CC850, 0x32DCE6, 0x3264F0, 0x9646DC, 0xFF6EBE, 0xF0F0F5, 0x23232D};
        return p[Cfg.clamp(idx, 0, 9)];
    }
}
