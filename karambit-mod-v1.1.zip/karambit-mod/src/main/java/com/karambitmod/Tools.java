package com.karambitmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.option.SimpleOption;
import net.minecraft.entity.effect.StatusEffectInstance;
import net.minecraft.entity.effect.StatusEffects;

/** Narzędzia: zoom pod klawiszem (zmiana FOV) i pełna jasność (klienckie Night Vision). */
public final class Tools {
    private static boolean zooming;
    private static int origFov = 70;
    private static double curFov = 70;
    private static boolean nvOurs;

    private Tools() {}

    public static void tick(MinecraftClient mc) {
        Cfg c = Cfg.I;
        zoom(mc, c);
        light(mc, c);
    }

    // ------------------------------------------------------------ zoom

    private static void zoom(MinecraftClient mc, Cfg c) {
        SimpleOption<Integer> fov = mc.options.getFov();
        boolean want = c.modEnabled && c.zoomEnabled && mc.player != null && mc.currentScreen == null
                && KarambitMod.ZOOM != null && KarambitMod.ZOOM.isPressed();
        if (want) {
            if (!zooming) {
                origFov = fov.getValue();
                curFov = origFov;
                zooming = true;
            }
            int target = Math.min(origFov, Cfg.clamp(c.zoomFov, 30, 110));
            curFov = c.zoomSmooth ? curFov + (target - curFov) * 0.45 : target;
            fov.setValue((int) Math.round(curFov));
        } else if (zooming) {
            if (c.zoomSmooth) {
                curFov += (origFov - curFov) * 0.45;
                if (Math.abs(origFov - curFov) < 1.5) { curFov = origFov; zooming = false; }
                fov.setValue((int) Math.round(curFov));
            } else {
                fov.setValue(origFov);
                zooming = false;
            }
        }
    }

    /** Przywraca FOV (np. przy zamykaniu gry w trakcie zoomu). */
    public static void restore(MinecraftClient mc) {
        if (zooming) {
            mc.options.getFov().setValue(origFov);
            zooming = false;
        }
    }

    // ------------------------------------------------------------ pełna jasność

    private static void light(MinecraftClient mc, Cfg c) {
        ClientPlayerEntity p = mc.player;
        if (p == null) { nvOurs = false; return; }
        StatusEffectInstance cur = p.getStatusEffect(StatusEffects.NIGHT_VISION);
        boolean want = c.modEnabled && c.fullbright;
        if (want) {
            if (cur == null) {
                p.addStatusEffect(new StatusEffectInstance(StatusEffects.NIGHT_VISION, 1_000_000, 0, true, false, false));
                nvOurs = true;
            }
        } else if (nvOurs) {
            if (cur != null && cur.getDuration() > 100_000) p.removeStatusEffect(StatusEffects.NIGHT_VISION);
            nvOurs = false;
        }
    }
}
