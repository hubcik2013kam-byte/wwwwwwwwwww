package com.karambitmod;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.font.TextRenderer;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.network.ClientPlayerEntity;
import net.minecraft.client.network.PlayerListEntry;
import net.minecraft.client.render.RenderTickCounter;
import net.minecraft.entity.Entity;
import net.minecraft.entity.EquipmentSlot;
import net.minecraft.entity.LivingEntity;
import net.minecraft.entity.player.PlayerInventory;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.text.Text;
import net.minecraft.util.hit.EntityHitResult;
import net.minecraft.util.hit.HitResult;
import net.minecraft.util.math.MathHelper;
import net.minecraft.world.LightType;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * Nowe elementy HUD: panel informacji (FPS, ping, XYZ...), ekwipunek (pancerz + liczniki),
 * pasek życia celu i kompas. Każdy ma też wersję "do podglądu" używaną w menu.
 */
public final class HudWidgets {
    private static final int GOOD = 0x55FF77, WARN = 0xFFD455, BAD = 0xFF5555, WHITE = 0xFFFFFF;
    private static final DateTimeFormatter CLOCK = DateTimeFormatter.ofPattern("HH:mm");

    private HudWidgets() {}

    private record Line(String label, String value, int color) {}
    private record Entry(ItemStack stack, String text, int color, float bar) {}

    // ============================================================ wejście

    public static void renderAll(DrawContext ctx, RenderTickCounter tick) {
        Stats.frame();
        Cfg c = Cfg.I;
        MinecraftClient mc = MinecraftClient.getInstance();
        if (!c.modEnabled || mc.options.hudHidden || mc.player == null) return;
        if (mc.currentScreen instanceof ConfigScreen) return;     // w menu rysują się podglądy
        TextRenderer tr = mc.textRenderer;
        int w = ctx.getScaledWindowWidth(), h = ctx.getScaledWindowHeight();
        if (c.infoEnabled) drawInfo(ctx, tr, w, h);
        if (c.equipEnabled) drawEquip(ctx, tr, w, h, false);
        if (c.targetEnabled) drawTarget(ctx, tr, w, h);
        if (c.compassEnabled) drawCompass(ctx, tr, w);
    }

    // ============================================================ panel informacji

    private static List<Line> infoLines(MinecraftClient mc, Cfg c) {
        List<Line> out = new ArrayList<>();
        ClientPlayerEntity p = mc.player;
        if (c.infoFps) {
            int f = Stats.fps;
            out.add(new Line("FPS", String.valueOf(f), f >= 60 ? GOOD : f >= 30 ? WARN : BAD));
        }
        if (c.infoPing && p != null && mc.getNetworkHandler() != null) {
            PlayerListEntry e = mc.getNetworkHandler().getPlayerListEntry(p.getUuid());
            if (e != null) {
                int ms = e.getLatency();
                out.add(new Line("Ping", ms + " ms", ms <= 80 ? GOOD : ms <= 160 ? WARN : BAD));
            }
        }
        if (c.infoCoords && p != null) {
            out.add(new Line("XYZ", String.format(Locale.ROOT, "%.1f / %.1f / %.1f", p.getX(), p.getY(), p.getZ()), WHITE));
            String dir = switch (p.getHorizontalFacing()) {
                case NORTH -> "Północ (-Z)";
                case SOUTH -> "Południe (+Z)";
                case EAST -> "Wschód (+X)";
                case WEST -> "Zachód (-X)";
                default -> "?";
            };
            out.add(new Line("Kierunek", dir, WHITE));
        }
        if (c.infoSpeed) {
            out.add(new Line("Prędkość", String.format(Locale.ROOT, "%.1f bl/s", Stats.speed), WHITE));
        }
        if (c.infoLight && p != null && mc.world != null) {
            int l = mc.world.getLightLevel(LightType.BLOCK, p.getBlockPos());
            out.add(new Line("Światło", String.valueOf(l), l == 0 ? BAD : l < 8 ? WARN : GOOD));
        }
        if (c.infoClock) {
            out.add(new Line("Czas", LocalTime.now().format(CLOCK), WHITE));
        }
        return out;
    }

    public static void drawInfo(DrawContext ctx, TextRenderer tr, int sw, int sh) {
        Cfg c = Cfg.I;
        List<Line> lines = infoLines(MinecraftClient.getInstance(), c);
        if (lines.isEmpty()) return;

        int lw = 0, vw = 0;
        for (Line l : lines) {
            lw = Math.max(lw, tr.getWidth(l.label()));
            vw = Math.max(vw, tr.getWidth(l.value()));
        }
        int bw = 9 + lw + 8 + vw + 6;
        int bh = lines.size() * 10 + 6;
        float s = c.infoScale;
        float x = (sw - bw * s) * c.infoX / 100f;
        float y = (sh - bh * s) * c.infoY / 100f;

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(x, y);
        ctx.getMatrices().scale(s, s);
        if (c.infoBg) {
            Gui.shadow(ctx, 0, 0, bw, bh, 3);
            Gui.roundRect(ctx, 0, 0, bw, bh, 3, 0xB0101018);
        }
        Gui.vGradient(ctx, 3, 3, 2, bh - 6, c.infoColorA, c.infoColorB);
        int n = Math.max(1, lines.size() - 1);
        for (int i = 0; i < lines.size(); i++) {
            Line l = lines.get(i);
            int ly = 3 + i * 10 + 1;
            int lc = Cfg.lerp(c.infoColorA, c.infoColorB, (float) i / n);
            ctx.drawTextWithShadow(tr, Text.literal(l.label()), 9, ly, 0xFF000000 | lc);
            ctx.drawTextWithShadow(tr, Text.literal(l.value()), 9 + lw + 8, ly, 0xFF000000 | l.color());
        }
        ctx.getMatrices().popMatrix();
    }

    // ============================================================ ekwipunek (pancerz + liczniki)

    private static Entry durable(ItemStack st, Cfg c) {
        int max = st.getMaxDamage();
        int left = max - st.getDamage();
        float f = max <= 0 ? 1f : Math.max(0f, Math.min(1f, left / (float) max));
        int col = f > 0.5f ? Cfg.lerp(WARN, GOOD, (f - 0.5f) * 2f) : Cfg.lerp(BAD, WARN, f * 2f);
        String t = c.equipMode == Cfg.ValueMode.PERCENT ? Math.round(f * 100f) + "%" : left + "/" + max;
        return new Entry(st, t, col, f);
    }

    private static int count(ClientPlayerEntity p, Item... items) {
        PlayerInventory inv = p.getInventory();
        int n = 0;
        int main = Math.min(36, inv.size());
        for (int i = 0; i < main; i++) {
            ItemStack s = inv.getStack(i);
            if (s.isEmpty()) continue;
            for (Item it : items) if (s.isOf(it)) n += s.getCount();
        }
        ItemStack off = p.getOffHandStack();
        for (Item it : items) if (off.isOf(it)) n += off.getCount();
        return n;
    }

    private static void addCount(List<Entry> out, ClientPlayerEntity p, boolean on, Item icon, Item... items) {
        if (!on) return;
        int n = count(p, items);
        if (n > 0) out.add(new Entry(new ItemStack(icon), "x" + n, WHITE, -1f));
    }

    private static List<Entry> equipEntries(ClientPlayerEntity p, Cfg c) {
        List<Entry> out = new ArrayList<>();
        if (c.equipArmor) {
            EquipmentSlot[] slots = {EquipmentSlot.HEAD, EquipmentSlot.CHEST, EquipmentSlot.LEGS, EquipmentSlot.FEET};
            for (EquipmentSlot slot : slots) {
                ItemStack st = p.getEquippedStack(slot);
                if (st.isEmpty()) continue;
                out.add(st.isDamageable() ? durable(st, c) : new Entry(st, "", WHITE, -1f));
            }
        }
        if (c.equipHeld) {
            ItemStack st = p.getMainHandStack();
            if (!st.isEmpty()) {
                if (st.isDamageable()) out.add(durable(st, c));
                else if (st.getCount() > 1) out.add(new Entry(st, "x" + st.getCount(), WHITE, -1f));
            }
        }
        addCount(out, p, c.equipTotem, Items.TOTEM_OF_UNDYING, Items.TOTEM_OF_UNDYING);
        addCount(out, p, c.equipPearl, Items.ENDER_PEARL, Items.ENDER_PEARL);
        addCount(out, p, c.equipApple, Items.GOLDEN_APPLE, Items.GOLDEN_APPLE, Items.ENCHANTED_GOLDEN_APPLE);
        addCount(out, p, c.equipArrow, Items.ARROW, Items.ARROW, Items.TIPPED_ARROW, Items.SPECTRAL_ARROW);
        addCount(out, p, c.equipCrystal, Items.END_CRYSTAL, Items.END_CRYSTAL);
        return out;
    }

    private static List<Entry> sampleEntries() {
        List<Entry> out = new ArrayList<>();
        out.add(new Entry(new ItemStack(Items.DIAMOND_HELMET), "100%", GOOD, 1f));
        out.add(new Entry(new ItemStack(Items.DIAMOND_CHESTPLATE), "78%", Cfg.lerp(WARN, GOOD, 0.56f), 0.78f));
        out.add(new Entry(new ItemStack(Items.DIAMOND_LEGGINGS), "45%", Cfg.lerp(BAD, WARN, 0.9f), 0.45f));
        out.add(new Entry(new ItemStack(Items.DIAMOND_BOOTS), "12%", BAD, 0.12f));
        out.add(new Entry(new ItemStack(Items.TOTEM_OF_UNDYING), "x2", WHITE, -1f));
        out.add(new Entry(new ItemStack(Items.ENDER_PEARL), "x16", WHITE, -1f));
        return out;
    }

    public static void drawEquip(DrawContext ctx, TextRenderer tr, int sw, int sh, boolean preview) {
        Cfg c = Cfg.I;
        MinecraftClient mc = MinecraftClient.getInstance();
        List<Entry> es = mc.player != null ? equipEntries(mc.player, c) : new ArrayList<>();
        if (es.isEmpty() && preview) es = sampleEntries();
        if (es.isEmpty()) return;

        boolean vert = c.equipLayout == Cfg.Layout.VERTICAL;
        int gap = vert ? 2 : 8;
        int n = es.size();
        int[] ew = new int[n];
        int maxW = 0, total = 0;
        for (int i = 0; i < n; i++) {
            Entry e = es.get(i);
            ew[i] = 16 + (e.text().isEmpty() ? 0 : 3 + tr.getWidth(e.text()));
            maxW = Math.max(maxW, ew[i]);
            total += ew[i];
        }
        int cw = vert ? maxW : total + gap * (n - 1);
        int ch = vert ? n * 16 + gap * (n - 1) : 16;
        int bw = cw + 8, bh = ch + 8;
        float s = c.equipScale;
        float x = (sw - bw * s) * c.equipX / 100f;
        float y = (sh - bh * s) * c.equipY / 100f;

        ctx.getMatrices().pushMatrix();
        ctx.getMatrices().translate(x, y);
        ctx.getMatrices().scale(s, s);
        Gui.roundRect(ctx, 0, 0, bw, bh, 3, 0x78101018);
        int cx = 4, cy = 4;
        for (int i = 0; i < n; i++) {
            Entry e = es.get(i);
            ctx.drawItem(e.stack(), cx, cy);
            if (e.bar() >= 0f && e.bar() < 1f) {
                ctx.fill(cx + 2, cy + 13, cx + 15, cy + 15, 0xFF000000);
                ctx.fill(cx + 2, cy + 13, cx + 2 + Math.round(13 * e.bar()), cy + 14, 0xFF000000 | e.color());
            }
            if (!e.text().isEmpty()) {
                ctx.drawTextWithShadow(tr, Text.literal(e.text()), cx + 19, cy + 4, 0xFF000000 | e.color());
            }
            if (vert) cy += 18; else cx += ew[i] + gap;
        }
        ctx.getMatrices().popMatrix();
    }

    // ============================================================ pasek życia celu

    private static void drawTarget(DrawContext ctx, TextRenderer tr, int sw, int sh) {
        Cfg c = Cfg.I;
        MinecraftClient mc = MinecraftClient.getInstance();
        HitResult hr = mc.crosshairTarget;
        if (hr == null || hr.getType() != HitResult.Type.ENTITY || mc.player == null) return;
        Entity e = ((EntityHitResult) hr).getEntity();
        if (!(e instanceof LivingEntity le) || !le.isAlive()) return;
        float dist = c.targetDistance ? mc.player.distanceTo(e) : -1f;
        targetCard(ctx, tr, sw / 2, sh / 2 + c.targetOffset, le.getName().getString(), le.getHealth(), le.getMaxHealth(), dist);
    }

    /** Karta celu: nazwa, pasek życia i (opcjonalnie) dystans. cx = środek poziomo, y = góra karty. */
    public static void targetCard(DrawContext ctx, TextRenderer tr, int cx, int y, String name, float hp, float max, float dist) {
        if (max <= 0f) max = 1f;
        float frac = Math.max(0f, Math.min(1f, hp / max));
        String info = String.format(Locale.ROOT, "♥ %.1f / %.1f", hp, max);
        if (dist >= 0f) info += String.format(Locale.ROOT, "   %.1f m", dist);
        int bw = Math.max(112, Math.max(tr.getWidth(name), tr.getWidth(info)) + 16);
        int x = cx - bw / 2;
        int bh = 32;

        Gui.shadow(ctx, x, y, x + bw, y + bh, 3);
        Gui.roundRect(ctx, x, y, x + bw, y + bh, 3, 0xB0101018);
        ctx.drawCenteredTextWithShadow(tr, Text.literal(name), cx, y + 4, 0xFFFFFFFF);

        int inner = bw - 12;
        Gui.roundRect(ctx, x + 6, y + 14, x + 6 + inner, y + 18, 1, 0xFF2A2A34);
        int fill = Math.round(inner * frac);
        if (fill > 0) {
            int col = Cfg.lerp(BAD, GOOD, frac);
            Gui.roundRect(ctx, x + 6, y + 14, x + 6 + fill, y + 18, 1, 0xFF000000 | col);
        }
        ctx.drawCenteredTextWithShadow(tr, Text.literal(info), cx, y + 21, 0xFFDDDDEE);
    }

    // ============================================================ kompas

    private static void drawCompass(DrawContext ctx, TextRenderer tr, int sw) {
        MinecraftClient mc = MinecraftClient.getInstance();
        if (mc.player == null) return;
        compassAt(ctx, tr, sw / 2, 10, Cfg.I.compassWidth, mc.player.getYaw());
    }

    /** Pasek kompasu z podziałką co 5° i podpisami N/NE/E/... cx = środek, y = góra, bw = szerokość (±90°). */
    public static void compassAt(DrawContext ctx, TextRenderer tr, int cx, int y, int bw, float yaw) {
        Cfg c = Cfg.I;
        float heading = MathHelper.wrapDegrees(yaw + 180f);      // 0 = północ
        if (heading < 0f) heading += 360f;

        Gui.shadow(ctx, cx - bw / 2 - 6, y - 1, cx + bw / 2 + 6, y + 19, 4);
        Gui.roundRect(ctx, cx - bw / 2 - 6, y - 1, cx + bw / 2 + 6, y + 19, 4, 0x90101018);
        for (int d = 0; d < 360; d += 5) {
            float rel = MathHelper.wrapDegrees(d - heading);
            float ar = Math.abs(rel);
            if (ar > 90f) continue;
            int a = (int) (255 * Math.min(1f, (90f - ar) / 40f));
            if (a < 16) continue;
            int px = cx + Math.round(rel / 90f * (bw / 2f));
            int rgb = Cfg.lerp(c.infoColorA, c.infoColorB, ar / 90f);
            boolean inter = d % 45 == 0;
            int th = inter ? 6 : (d % 15 == 0 ? 4 : 2);
            ctx.fill(px, y + 17 - th, px + 1, y + 17, (a << 24) | rgb);
            if (inter) {
                String lab = switch (d) {
                    case 0 -> "N";
                    case 45 -> "NE";
                    case 90 -> "E";
                    case 135 -> "SE";
                    case 180 -> "S";
                    case 225 -> "SW";
                    case 270 -> "W";
                    default -> "NW";
                };
                int tc = d % 90 == 0 ? 0xFFFFFF : 0xAAAAAA;
                ctx.drawCenteredTextWithShadow(tr, Text.literal(lab), px, y + 1, (a << 24) | tc);
            }
        }
        // znacznik środka (trójkącik)
        ctx.fill(cx - 2, y - 5, cx + 3, y - 4, 0xFFFFFFFF);
        ctx.fill(cx - 1, y - 4, cx + 2, y - 3, 0xFFFFFFFF);
        ctx.fill(cx, y - 3, cx + 1, y - 2, 0xFFFFFFFF);
    }
}
