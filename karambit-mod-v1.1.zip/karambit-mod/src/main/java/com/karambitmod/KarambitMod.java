package com.karambitmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientLifecycleEvents;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.util.Identifier;
import org.lwjgl.glfw.GLFW;

public class KarambitMod implements ClientModInitializer {
    public static final String ID = "karambitmod";

    public static KeyBinding OPEN_MENU;
    public static KeyBinding SPOTIFY_NEXT;
    public static KeyBinding SPOTIFY_PREV;
    public static KeyBinding SPOTIFY_PLAY;
    public static KeyBinding ZOOM;

    @Override
    public void onInitializeClient() {
        Cfg.load();

        // Kategoria w Opcje -> Sterowanie (1.21.9+)
        KeyBinding.Category cat = KeyBinding.Category.create(Identifier.of(ID, "main"));

        // P domyślnie; zmienisz w Opcje -> Sterowanie -> Karambit Mod
        OPEN_MENU = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key." + ID + ".open", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_P, cat));
        int none = GLFW.GLFW_KEY_UNKNOWN;
        SPOTIFY_NEXT = KeyBindingHelper.registerKeyBinding(new KeyBinding("key." + ID + ".next", InputUtil.Type.KEYSYM, none, cat));
        SPOTIFY_PREV = KeyBindingHelper.registerKeyBinding(new KeyBinding("key." + ID + ".prev", InputUtil.Type.KEYSYM, none, cat));
        SPOTIFY_PLAY = KeyBindingHelper.registerKeyBinding(new KeyBinding("key." + ID + ".play", InputUtil.Type.KEYSYM, none, cat));

        ZOOM = KeyBindingHelper.registerKeyBinding(
                new KeyBinding("key." + ID + ".zoom", InputUtil.Type.KEYSYM, GLFW.GLFW_KEY_Z, cat));

        Effects.init();
        ClientLifecycleEvents.CLIENT_STOPPING.register(Tools::restore);

        ClientTickEvents.END_CLIENT_TICK.register(mc -> {
            while (OPEN_MENU.wasPressed()) {
                if (mc.currentScreen == null) mc.setScreen(new ConfigScreen(null));
            }
            while (SPOTIFY_NEXT.wasPressed()) Spotify.next();
            while (SPOTIFY_PREV.wasPressed()) Spotify.previous();
            while (SPOTIFY_PLAY.wasPressed()) Spotify.playPause();
            Stats.tick(mc);
            Tools.tick(mc);
            ParticleEngine.tick(mc);
            RainEngine.tick(mc);
            Effects.tick(mc);
        });

        HudRenderCallback.EVENT.register((ctx, tick) -> {
            HudRenderer.render(ctx, tick);
            HudWidgets.renderAll(ctx, tick);
        });
        Spotify.start();
    }
}
