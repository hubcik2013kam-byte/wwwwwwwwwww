#!/usr/bin/env python3
"""Generuje tekstury karambitow 256x256 (render 1024 -> zmniejszenie), modele i definicje itemow.
Uruchom:  python3 tools/gen_assets.py [--preview]     (wymaga Pillow + numpy)
Nazwa: k<ksztalt>_<A>_<B>  -> gradient ostrza od koloru A (przy rekojesci) do B (czubek); pierscien w kolorze A.
Ksztalt wzorowany na prawdziwym karambicie (sierpowate ostrze, czarna rekojesc z wglebieniami na palce, pierscien).
"""
import json, math, os, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFilter

ROOT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "..", "src", "main", "resources", "assets", "karambitmod")
PAL = [(220, 40, 50), (255, 140, 30), (250, 220, 50), (60, 200, 80), (50, 220, 230),
       (50, 100, 240), (150, 70, 220), (255, 110, 190), (240, 240, 245), (35, 35, 45)]

W = 1024          # rozdzielczosc robocza
OUT = 256         # rozdzielczosc tekstury
SC = 2.0          # skala: wspolrzedne wzorca -> piksele robocze
OFF = (70, 60)
ROT = -36         # obrot w stopniach (ujemny = zgodnie z ruchem wskazowek), zeby ikona byla po przekatnej

# ---- ksztalty ostrza we wspolrzednych wzorca (~420x480). spine: podstawa -> czubek (wypukly grzbiet),
#      edge: czubek -> podstawa (wklesla krawedz tnaca). Kazdy to 4 punkty kontrolne krzywej Beziera 3. stopnia.
SHAPES = [
    dict(spine=[(298, 174), (302, 104), (196, 14), (82, 8)],      edge=[(82, 8), (140, 48), (206, 112), (238, 170)]),     # klasyczny
    dict(spine=[(298, 174), (314, 92), (150, -26), (34, 52)],     edge=[(34, 52), (96, 56), (192, 104), (238, 170)]),     # hawk: dluzszy hak
    dict(spine=[(300, 174), (312, 120), (222, 22), (100, 16)],    edge=[(100, 16), (152, 54), (214, 114), (240, 170)]),   # gruby
]
HANDLE_POLY = [(198, 198), (206, 184), (226, 174), (262, 170), (296, 172), (303, 184), (303, 214), (299, 262),
               (295, 312), (291, 356), (289, 392), (282, 414), (268, 430), (250, 436), (226, 438), (208, 430), (204, 410),
               (212, 384), (210, 350), (206, 300), (204, 250), (200, 220)]
GROOVES = [((218, 240), 19), ((218, 300), 19), ((218, 358), 19)]    # wglebienia na palce
RING_C, RING_RX, RING_RY, RING_TILT, RING_IN = (190, 410), 52, 48, -12, 0.58
NOTCH = ((248, 160), 11)                                            # wyciecie przy podstawie ostrza


def T(p):
    return np.array([p[0] * SC + OFF[0], p[1] * SC + OFF[1]], dtype=np.float32)


def cubic(pts, n=500):
    p0, p1, p2, p3 = [T(p) for p in pts]
    t = np.linspace(0, 1, n)[:, None]
    return (1 - t) ** 3 * p0 + 3 * (1 - t) ** 2 * t * p1 + 3 * (1 - t) * t ** 2 * p2 + t ** 3 * p3


def poly_mask(pts):
    im = Image.new("L", (W, W), 0)
    ImageDraw.Draw(im).polygon([tuple(map(float, p)) for p in pts], fill=255)
    return np.array(im) > 127


def min_dist(xs, ys, curve, step=5):
    d = np.full(xs.shape, 1e9, dtype=np.float32)
    for px, py in curve[::step]:
        np.minimum(d, np.hypot(xs - px, ys - py), out=d)
    return d


def blur01(mask, r):
    return np.array(Image.fromarray((mask * 255).astype(np.uint8), "L").filter(ImageFilter.GaussianBlur(r))).astype(np.float32) / 255


class Geo:
    """Czesc zalezna tylko od ksztaltu (liczona raz na ksztalt, nie na kolor)."""

    def __init__(self, shape):
        sh = SHAPES[shape]
        ys, xs = np.mgrid[0:W, 0:W].astype(np.float32)
        xs += 0.5; ys += 0.5
        self.xs, self.ys = xs, ys

        spine = cubic(sh["spine"]); edge = cubic(sh["edge"])
        blade = poly_mask(np.vstack([spine, edge]))
        nc, nr = T(NOTCH[0]), NOTCH[1] * SC
        blade &= np.hypot(xs - nc[0], ys - nc[1]) > nr
        self.blade = blade

        # --- pierscien (elipsa obrocona)
        rc = T(RING_C); ca, sa = math.cos(math.radians(RING_TILT)), math.sin(math.radians(RING_TILT))
        dx, dy = xs - rc[0], ys - rc[1]
        ex, ey = dx * ca + dy * sa, -dx * sa + dy * ca
        s = np.hypot(ex / (RING_RX * SC), ey / (RING_RY * SC))
        ring = (s <= 1.0) & (s >= RING_IN)
        self.ring_s = s; self.ring_dx = dx; self.ring_dy = dy

        # --- rekojesc: wielokat z wglebieniami na palce, nie wchodzi do otworu pierscienia
        handle = poly_mask([T(p) for p in HANDLE_POLY])
        for (c, r) in GROOVES:
            gc = T(c)
            handle &= np.hypot(xs - gc[0], ys - gc[1]) > r * SC
        handle &= ~(s < RING_IN + 0.02)
        self.handle = handle; self.ring = ring & ~handle

        alpha = blade | handle | ring
        a_img = Image.fromarray((alpha * 255).astype(np.uint8), "L")
        self.alpha = alpha
        self.full = np.array(a_img.filter(ImageFilter.MaxFilter(11))) > 127   # z obrysem (5 px = ~1.3 px w teksturze)

        # --- ostrze: wspolrzedne wzgledem krawedzi/grzbietu
        da = min_dist(xs, ys, edge); ds = min_dist(xs, ys, spine)
        u = da / np.maximum(da + ds, 1e-3)
        b0 = 0.5 * (spine[0] + edge[-1]); b1 = spine[-1]
        v = b1 - b0
        g = np.clip(((xs - b0[0]) * v[0] + (ys - b0[1]) * v[1]) / (v @ v), 0, 1)
        self.u, self.g, self.da = u, g, da

        face = 1.06 - 0.38 * np.clip((u - 0.16) / 0.84, 0, 1) ** 1.2
        sheen1 = np.exp(-((u - 0.40 - 0.10 * g) / 0.055) ** 2) * np.clip(1.25 - g, 0, 1)
        sheen2 = np.exp(-((u - 0.74) / 0.03) ** 2) * 0.30
        diag = np.exp(-((g - 0.45) / 0.12) ** 2) * 0.18 * (u > 0.2)
        self.face = face
        self.spec = np.clip(sheen1 * 0.55 + sheen2 + diag, 0, 1)
        self.bw = (0.35 + 0.55 * np.clip(1 - u / 0.14, 0, 1) ** 1.5) * (u < 0.14)
        self.groove = np.exp(-((u - 0.14) / 0.012) ** 2)
        self.fuller = np.exp(-((u - 0.60) / 0.02) ** 2)
        self.fuller_h = np.exp(-((u - 0.635) / 0.014) ** 2)
        self.spine_rim = np.clip((u - 0.90) / 0.06, 0, 1) * 0.85
        self.edge_line = np.clip(1 - da / 6.0, 0, 1)
        self.marble = np.clip(0.5 + 0.28 * np.sin(xs * 0.021 + 2.5 * np.sin(ys * 0.012))
                              + 0.22 * np.sin(ys * 0.017 + 1.7 * np.sin(xs * 0.015 + 1.0)), 0, 1)
        # gwiazdki (stala losowosc, powtarzalne)
        rng = np.random.default_rng(1234 + shape)
        st = Image.new("L", (W, W), 0); dr = ImageDraw.Draw(st)
        n = 0
        while n < 38:
            x, y = rng.integers(0, W, 2)
            if blade[y, x] and self.u[y, x] > 0.2:
                r = rng.uniform(2, 5); dr.ellipse([x - r, y - r, x + r, y + r], fill=int(rng.uniform(140, 255))); n += 1
        self.stars = np.array(st.filter(ImageFilter.GaussianBlur(1.5))).astype(np.float32) / 255

        # --- rekojesc: cieniowanie (niezalezne od koloru)
        b = blur01(handle, 9)
        interior = np.clip((b - 0.5) * 2.2, 0, 1)
        self.h_interior = interior
        self.h_rim = np.exp(-((b - 0.74) / 0.06) ** 2) * handle
        # swiatlo z lewej: jasniejsze wypukle krawedzie lobow
        hx0, hx1 = T((200, 0))[0], T((303, 0))[0]
        nx = np.clip((xs - hx0) / (hx1 - hx0), 0, 1)
        self.h_light = np.exp(-((nx - 0.18) / 0.22) ** 2)
        # lekkie rowki / grip: kropki po prawej, ryfle na dole, listwy u gory
        pw = 16.0
        gx = np.mod(xs, pw) - pw / 2
        gy = np.mod(ys + (np.floor(xs / pw) % 2) * pw / 2, pw) - pw / 2
        dots = (np.hypot(gx, gy) < 3.8).astype(np.float32)
        x0, x1 = T((258, 236)), T((296, 336))
        reg = ((xs > x0[0]) & (xs < x1[0]) & (ys > x0[1]) & (ys < x1[1])).astype(np.float32)
        reg = blur01(reg > 0.5, 6)
        self.h_dots = dots * reg * handle
        yy0, yy1 = T((0, 372))[1], T((0, 404))[1]
        rid = ((ys > yy0) & (ys < yy1) & (xs > T((262, 0))[0]) & (xs < T((292, 0))[0]))
        self.h_ridge = (np.mod(ys, 14) < 5).astype(np.float32) * rid * handle
        top = ((ys > T((0, 176))[1]) & (ys < T((0, 208))[1]) & (xs > T((228, 0))[0]) & (xs < T((300, 0))[0]))
        self.h_top = (np.mod(xs, 12) < 4).astype(np.float32) * top * handle

        # --- pierscien: cieniowanie
        sr = s
        tube = (sr - (1 + RING_IN) / 2) / ((1 - RING_IN) / 2)
        rd = np.maximum(np.hypot(self.ring_dx, self.ring_dy), 1)
        ang = (self.ring_dx * -0.6 + self.ring_dy * -0.8) / rd
        center = np.clip(1 - np.abs(tube), 0, 1)
        sh_ = 0.78 + 0.45 * ang * np.clip(1.4 * center, 0, 1) + 0.22 * center
        sh_ = np.where(np.abs(tube) > 0.82, sh_ * 0.58, sh_)
        self.r_shade = sh_
        self.r_spec = np.exp(-((tube + 0.30) / 0.14) ** 2) * np.clip(-ang, 0, 1) * 0.55


def colorize(G, ca, cb):
    A = np.array(PAL[ca], dtype=np.float32); B = np.array(PAL[cb], dtype=np.float32)
    rgb = np.zeros((W, W, 3), dtype=np.float32)

    # ---- ostrze
    g = G.g[..., None]
    base = A[None, None] * (1 - g) + B[None, None] * g
    base = base * (0.90 + 0.20 * g) * (0.82 + 0.36 * G.marble[..., None])
    br = base * G.face[..., None]
    br = br + (255 - br) * G.spec[..., None] * 0.75
    steel = np.array([232, 238, 248], dtype=np.float32)
    bw = G.bw[..., None]
    br = br * (1 - bw) + steel * bw
    br = br * (1 - 0.35 * G.groove[..., None])
    br = br * (1 - 0.30 * G.fuller[..., None]) + 255 * 0.22 * G.fuller_h[..., None]
    sp = G.spine_rim[..., None]
    br = br * (1 - sp) + np.array([22, 22, 32], dtype=np.float32) * sp
    el = G.edge_line[..., None]
    br = br * (1 - 0.8 * el) + 255 * 0.8 * el
    br = br + (255 - br) * G.stars[..., None] * 0.9
    rgb[G.blade] = np.clip(br[G.blade], 0, 255)

    # ---- pierscien: kolor A z metalicznym polyskiem
    rb = (A * 0.75 + 45)[None, None]
    rr = rb * G.r_shade[..., None]
    rr = rr + (255 - rr) * G.r_spec[..., None]
    rgb[G.ring] = np.clip(rr[G.ring], 0, 255)

    # ---- rekojesc: czarna guma z jasniejszymi krawedziami
    val = (20 + 26 * G.h_light) * (0.55 + 0.45 * G.h_interior)
    hh = np.stack([val, val, val * 1.12], axis=-1) + A[None, None] * 0.05
    rim = G.h_rim[..., None]
    hh = hh * (1 - rim) + (np.array([62, 62, 80], dtype=np.float32) + A * 0.22)[None, None] * rim
    hh = hh + 38 * G.h_dots[..., None]
    hh = hh * (1 - 0.45 * G.h_ridge[..., None])
    hh = hh * (1 - 0.35 * G.h_top[..., None]) + 14 * G.h_top[..., None]
    rgb[G.handle] = np.clip(hh[G.handle], 0, 255)

    # ---- obrys: ciemny, lekko w kolorze ostrza
    outline = G.full & ~G.alpha
    rgb[outline] = A * 0.14 + np.array([6, 6, 12], dtype=np.float32)

    rgba = np.zeros((W, W, 4), dtype=np.uint8)
    rgba[..., :3] = np.clip(rgb, 0, 255).astype(np.uint8)
    rgba[..., 3] = (G.full * 255).astype(np.uint8)
    img = Image.fromarray(rgba, "RGBA")

    # obrot po przekatnej, dopasowanie do kadru i zmniejszenie do OUT
    img = img.rotate(ROT, resample=Image.BICUBIC, expand=True)
    img = img.crop(img.getbbox())
    side = int(max(img.size) * 1.05)
    canvas = Image.new("RGBA", (side, side), (0, 0, 0, 0))
    canvas.paste(img, ((side - img.size[0]) // 2, (side - img.size[1]) // 2))
    return canvas.resize((OUT, OUT), Image.LANCZOS)


def main():
    tex = os.path.join(ROOT, "textures", "item")
    mdl = os.path.join(ROOT, "models", "item")
    itm = os.path.join(ROOT, "items")
    for d in (tex, mdl, itm):
        os.makedirs(d, exist_ok=True)
    n = 0
    prev = {}
    for s in range(len(SHAPES)):
        G = Geo(s)
        for a in range(len(PAL)):
            for b in range(len(PAL)):
                name = f"k{s}_{a}_{b}"
                im = colorize(G, a, b)
                im.save(os.path.join(tex, name + ".png"), optimize=True)
                if (a, b) in ((0, 5), (6, 7), (4, 6), (1, 2)): prev[(s, a, b)] = im
                with open(os.path.join(mdl, name + ".json"), "w") as f:
                    json.dump({"parent": "minecraft:item/handheld",
                               "textures": {"layer0": f"karambitmod:item/{name}"}}, f)
                with open(os.path.join(itm, name + ".json"), "w") as f:
                    json.dump({"model": {"type": "minecraft:model", "model": f"karambitmod:item/{name}"}}, f)
                n += 1
        print("ksztalt", s, "gotowy", flush=True)
    print("wygenerowano", n, "karambitow")
    if "--preview" in sys.argv:
        pairs = [(0, 5), (6, 7), (4, 6)]
        sheet = Image.new("RGBA", (3 * OUT, len(pairs) * OUT), (70, 70, 78, 255))
        for s in range(3):
            for k, (a, b) in enumerate(pairs):
                sheet.alpha_composite(prev[(s, a, b)], (s * OUT, k * OUT))
        sheet.save("/home/claude/preview.png")


if __name__ == "__main__":
    main()
