# Karambit Mod (Fabric, Minecraft 1.21.11, tylko klient)

## Co robi
Każdą funkcję można wyłączyć: zakładka **Ogólne** ma główny włącznik całego moda i włączniki modułów (karambit, cząsteczki, deszcz, Spotify, okienko, panel informacji, ekwipunek, efekty, pasek celu, kompas), a każda zakładka ma włącznik na górze, który przyciemnia resztę jej opcji.

- **P** otwiera menu moda (ciemny, zaokrąglony panel z cieniem, gradientowym akcentem i płynnymi animacjami przycisków, przełączniki, suwaki, podgląd karambita na żywo) (zmiana klawisza: Opcje → Sterowanie → *Karambit Mod*). Są też opcjonalne, nieprzypisane klawisze Spotify: następny / poprzedni / pauza.
- **Karambit** zamiast każdego miecza (3 kształty, 10 kolorów, gradient od koloru A do B).
- **Cząsteczki**: wokół miecza w ręce / wskazywanego bloku / gracza. Kształty: orbita, spirala, pierścień, gwiazda, serce, sześcian, sfera, chmura, smuga. Gradient (kolory w hex), ilość, rozmiar, promień, prędkość, typ cząsteczek.
- **Deszcz**: gdy pada, na odkrytym terenie wokół gracza pojawiają się krople, które podskakują (kilka odbić) i kończą pluskiem. Gęstość, sprężystość, rozmiar, zasięg i gradient kolorów w zakładce *Deszcz*.
- **Panel informacji** (zakładka *Info*): FPS, ping, współrzędne XYZ z kierunkiem, prędkość (bloki/s), poziom światła (czerwony = mobki mogą się pojawić), zegar. Gradientowy akcent, kolory w hex, pozycja X/Y, skala, opcjonalne tło.
- **Ekwipunek HUD** (zakładka *Ekwipunek*): wytrzymałość pancerza i przedmiotu w ręce (pasek + procenty albo liczby, kolor zielony → czerwony) oraz liczniki: totemy, perły Endu, złote jabłka, strzały, kryształy Endu. Układ pionowy / poziomy, pozycja, skala.
- **Efekty świata** (zakładka *Efekty*): ślad kroków (opcjonalnie tylko w sprincie), iskry przy trafieniu przeciwnika, świetliki dryfujące wokół gracza (domyślnie tylko po ciemku). Wspólne: typ cząsteczek, rozmiar, gradient hex.
- **Narzędzia** (zakładka *Narzędzia*): zoom pod klawiszem **Z** (zmiana w Sterowaniu; płynny, FOV do 30), pełna jasność (klienckie Night Vision; sprawdź regulamin serwera), pasek życia celu z dystansem pod celownikiem, kompas na górze ekranu.
- **Spotify "Teraz gra"** na HUD: gradient tekstu i paska postępu, pozycja X/Y, skala, podgląd na żywo w menu. Przyciski ⏮ ⏯ ⏭ (wymagają Premium).

## Budowanie
1. Java 21.
2. W `gradle.properties` ustaw aktualne wersje z https://fabricmc.net/develop (yarn, loader, fabric-api dla 1.21.11). Wpisane tam wartości to moje przypuszczenie.
3. Wrapper: `gradle wrapper` (albo skopiuj `gradlew*` i `gradle/` z szablonu Fabric), potem `./gradlew build`.
4. Gotowy jar: `build/libs/karambitmod-1.0.0.jar` → do `.minecraft/mods` razem z Fabric API.

Tekstury (256x256, kształt wzorowany na prawdziwym karambicie) i modele karambitów generuje `python3 tools/gen_assets.py` (wymaga Pillow i numpy; już wygenerowane, 300 sztuk).

## Podpięcie Spotify (jednorazowo)
1. https://developer.spotify.com/dashboard → *Create app*.
2. Redirect URI: `http://127.0.0.1:8888/callback`, zaznacz *Web API*.
3. Skopiuj **Client ID**, wklej w menu moda (zakładka Spotify) → *Połącz ze Spotify* → zaakceptuj w przeglądarce.
4. W trybie deweloperskim dodaj swoje konto w *User Management* aplikacji.

Token odświeżający zapisuje się jawnie w `config/karambitmod.json`, nie udostępniaj tego pliku.

## Uwaga
Kod napisany bez możliwości kompilacji. Najbardziej prawdopodobne poprawki przy pierwszym buildzie to nazwy API zmienione w 1.21.x (np. `addParticleClient`, `HudRenderCallback`, miejsce `@At("STORE")` w `ItemModelManagerMixin`). Nowe moduły (`Stats`, `HudWidgets`, `Effects`, `Tools`) nie używają żadnych mixinów, tylko API Fabric i vanilla.
